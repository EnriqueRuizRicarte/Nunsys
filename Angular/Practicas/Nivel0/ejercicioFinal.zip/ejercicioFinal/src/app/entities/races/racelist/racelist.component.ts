import { Component, OnInit } from '@angular/core';
import { RaceService } from '../race.service';
import { Race } from '../race.model';

@Component({
  selector: 'app-racelist',
  templateUrl: './racelist.component.html',
  styleUrls: ['./racelist.component.css']
})
export class RacelistComponent implements OnInit {
  races:Race[]=[];
  constructor(private _raceService: RaceService) { 
    this.races = _raceService.getAllRaces();
  }

  ngOnInit() {
  }

}
