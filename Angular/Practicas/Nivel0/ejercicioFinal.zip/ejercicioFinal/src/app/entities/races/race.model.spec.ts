import { Race } from './race.model';

describe('Race', () => {
  it('should create an instance', () => {
    expect(new Race()).toBeTruthy();
  });
});
