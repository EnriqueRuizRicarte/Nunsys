import { Injectable } from '@angular/core';
import { Race, Bando } from './race.model';

@Injectable({
  providedIn: 'root'
})
export class RaceService {

  races: Race[] = [
    { id: 1, imagen: "../../../assets/imgs/razas/alianza/draenei.png", nombre: "Draenei", descripcion: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus turpis eros, condimentum vel libero sit amet, pulvinar ornare lectus.", detail: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus turpis eros, condimentum vel libero sit amet, pulvinar ornare lectus. Proin sagittis ante tristique venenatis porta. Curabitur dignissim, dui eu varius pellentesque, ligula arcu sagittis felis, id sodales leo urna bibendum orci. Praesent in ornare elit, imperdiet ornare erat. Etiam fermentum facilisis arcu, in eleifend orci finibus quis. Donec egestas sollicitudin rhoncus. Vestibulum massa ligula, accumsan quis eleifend sit amet, scelerisque sed lacus.", bando: Bando.alianza },
    { id: 2, imagen: "../../../assets/imgs/razas/alianza/elfo.png", nombre: "Elfo", descripcion: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus turpis eros, condimentum vel libero sit amet, pulvinar ornare lectus. ", detail: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus turpis eros, condimentum vel libero sit amet, pulvinar ornare lectus. Proin sagittis ante tristique venenatis porta. Curabitur dignissim, dui eu varius pellentesque, ligula arcu sagittis felis, id sodales leo urna bibendum orci. Praesent in ornare elit, imperdiet ornare erat. Etiam fermentum facilisis arcu, in eleifend orci finibus quis. Donec egestas sollicitudin rhoncus. Vestibulum massa ligula, accumsan quis eleifend sit amet, scelerisque sed lacus.", bando: Bando.alianza },
    { id: 3, imagen: "../../../assets/imgs/razas/alianza/enano.png", nombre: "Enano", descripcion: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus turpis eros, condimentum vel libero sit amet, pulvinar ornare lectus. ", detail: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus turpis eros, condimentum vel libero sit amet, pulvinar ornare lectus. Proin sagittis ante tristique venenatis porta. Curabitur dignissim, dui eu varius pellentesque, ligula arcu sagittis felis, id sodales leo urna bibendum orci. Praesent in ornare elit, imperdiet ornare erat. Etiam fermentum facilisis arcu, in eleifend orci finibus quis. Donec egestas sollicitudin rhoncus. Vestibulum massa ligula, accumsan quis eleifend sit amet, scelerisque sed lacus.", bando: Bando.alianza },
    { id: 4, imagen: "../../../assets/imgs/razas/alianza/humano.png", nombre: "Humano", descripcion: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus turpis eros, condimentum vel libero sit amet, pulvinar ornare lectus. ", detail: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus turpis eros, condimentum vel libero sit amet, pulvinar ornare lectus. Proin sagittis ante tristique venenatis porta. Curabitur dignissim, dui eu varius pellentesque, ligula arcu sagittis felis, id sodales leo urna bibendum orci. Praesent in ornare elit, imperdiet ornare erat. Etiam fermentum facilisis arcu, in eleifend orci finibus quis. Donec egestas sollicitudin rhoncus. Vestibulum massa ligula, accumsan quis eleifend sit amet, scelerisque sed lacus.", bando: Bando.alianza },
    { id: 5, imagen: "../../../assets/imgs/razas/horda/elfo-oscuro.png", nombre: "Elfo Oscuro", descripcion: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus turpis eros, condimentum vel libero sit amet, pulvinar ornare lectus. ", detail: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus turpis eros, condimentum vel libero sit amet, pulvinar ornare lectus. Proin sagittis ante tristique venenatis porta. Curabitur dignissim, dui eu varius pellentesque, ligula arcu sagittis felis, id sodales leo urna bibendum orci. Praesent in ornare elit, imperdiet ornare erat. Etiam fermentum facilisis arcu, in eleifend orci finibus quis. Donec egestas sollicitudin rhoncus. Vestibulum massa ligula, accumsan quis eleifend sit amet, scelerisque sed lacus.", bando: Bando.horda },
    { id: 6, imagen: "../../../assets/imgs/razas/horda/ogro.png", nombre: "Ogro", descripcion: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus turpis eros, condimentum vel libero sit amet, pulvinar ornare lectus. ", detail: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus turpis eros, condimentum vel libero sit amet, pulvinar ornare lectus. Proin sagittis ante tristique venenatis porta. Curabitur dignissim, dui eu varius pellentesque, ligula arcu sagittis felis, id sodales leo urna bibendum orci. Praesent in ornare elit, imperdiet ornare erat. Etiam fermentum facilisis arcu, in eleifend orci finibus quis. Donec egestas sollicitudin rhoncus. Vestibulum massa ligula, accumsan quis eleifend sit amet, scelerisque sed lacus.", bando: Bando.horda },
    { id: 7, imagen: "../../../assets/imgs/razas/horda/sanlayn.png", nombre: "Sanlayn", descripcion: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus turpis eros, condimentum vel libero sit amet, pulvinar ornare lectus..", detail: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus turpis eros, condimentum vel libero sit amet, pulvinar ornare lectus. Proin sagittis ante tristique venenatis porta. Curabitur dignissim, dui eu varius pellentesque, ligula arcu sagittis felis, id sodales leo urna bibendum orci. Praesent in ornare elit, imperdiet ornare erat. Etiam fermentum facilisis arcu, in eleifend orci finibus quis. Donec egestas sollicitudin rhoncus. Vestibulum massa ligula, accumsan quis eleifend sit amet, scelerisque sed lacus.", bando: Bando.horda },
    { id: 8, imagen: "../../../assets/imgs/razas/horda/tauren.png", nombre: "Tauren", descripcion: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus turpis eros, condimentum vel libero sit amet, pulvinar ornare lectus. ", detail: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus turpis eros, condimentum vel libero sit amet, pulvinar ornare lectus. Proin sagittis ante tristique venenatis porta. Curabitur dignissim, dui eu varius pellentesque, ligula arcu sagittis felis, id sodales leo urna bibendum orci. Praesent in ornare elit, imperdiet ornare erat. Etiam fermentum facilisis arcu, in eleifend orci finibus quis. Donec egestas sollicitudin rhoncus. Vestibulum massa ligula, accumsan quis eleifend sit amet, scelerisque sed lacus.", bando: Bando.horda }
  ];
  constructor() { }

  getAllRaces() {
    return this.races;
  }

  getRaceById(idx) {
    return this.races.find(race => race.id === idx);
  }

  /* tipoDeBando(bando:Bando){
    if(bando === Bando.horda){
     return "../../../../assets/imgs/escudos/horde.png";
    }else{
      return "../../../../assets/imgs/escudos/alliance.png";
    }
    
  } */
}
