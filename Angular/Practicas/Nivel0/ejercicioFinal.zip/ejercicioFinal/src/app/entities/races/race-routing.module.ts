import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RacedetailsComponent } from './racedetails/racedetails.component';
import { RacelistComponent } from './racelist/racelist.component';

const routes: Routes = [
  {path:'race/:id', component:RacedetailsComponent, pathMatch:'full'},
  {path:'racelist', component:RacelistComponent, pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RaceRoutingModule { }
