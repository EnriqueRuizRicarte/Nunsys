import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RacecardComponent } from './racecard.component';

describe('RacecardComponent', () => {
  let component: RacecardComponent;
  let fixture: ComponentFixture<RacecardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RacecardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RacecardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
