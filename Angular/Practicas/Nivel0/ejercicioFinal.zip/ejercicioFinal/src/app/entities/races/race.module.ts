import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RaceRoutingModule } from './race-routing.module';
import { RacelistComponent } from './racelist/racelist.component';
import { RacecardComponent } from './racecard/racecard.component';
import { RacedetailsComponent } from './racedetails/racedetails.component';

@NgModule({
  declarations: [RacelistComponent, RacecardComponent, RacedetailsComponent],
  imports: [
    CommonModule,
    RaceRoutingModule
  ]
})
export class RaceModule { }
