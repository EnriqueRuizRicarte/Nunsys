import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Race } from '../race.model';
import { RaceService } from '../race.service';

@Component({
  selector: 'app-racedetails',
  templateUrl: './racedetails.component.html',
  styleUrls: ['./racedetails.component.css']
})
export class RacedetailsComponent implements OnInit {

  id: String;
  raceParam:Race;
  
  constructor(private route:ActivatedRoute, private _raceService:RaceService) { 
    
    this.route.paramMap.subscribe(x =>{
    this.id = x.get("id");
    })
    this.raceParam = _raceService.getRaceById(+this.id);
    console.log(this.raceParam);
    
  }

  ngOnInit() {
  }

}
