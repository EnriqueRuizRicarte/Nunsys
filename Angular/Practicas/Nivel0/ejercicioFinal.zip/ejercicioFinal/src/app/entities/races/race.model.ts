export enum Bando{
    alianza = 0,
    horda = 1
}

export class Race {
    id:number;
    imagen:String;
    nombre:String;
    descripcion:String;
    detail:String;
    bando:Bando;
}
