import { Component, OnInit, Input } from '@angular/core';
import { Race, Bando } from '../race.model';
import { Router } from '@angular/router';
import { TestBed } from '@angular/core/testing';
import { RaceService } from '../race.service';

@Component({
  selector: 'app-racecard',
  templateUrl: './racecard.component.html',
  styleUrls: ['./racecard.component.css']
})
export class RacecardComponent implements OnInit {

  @Input() public raceInfo:Race;


  constructor(private router:Router, private _raceService:RaceService) {
    //console.log(this.raceInfo.bando);
    // this.escudo = this._raceService.tipoDeBando(this.raceInfo.bando);
   }

  ngOnInit() {
  }

  obtenerEscudo(raza:Race): string{
    if(raza.bando === Bando.alianza){
      return 'alianza';
    }else{
      return 'horda';
    }
  }
  verDetail(id:number){
    this.router.navigate(['/race',id]);
  }
  
  
}
